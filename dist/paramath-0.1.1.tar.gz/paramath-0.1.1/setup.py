from setuptools import setup, find_packages

#package setup file

setup(
    name="paramath",
    version="0.1.1",
    packages=find_packages(),
    author="Tamer Alssaleh (Paradoxial)",
    author_email="tameralssaleh8@gmail.com"
)